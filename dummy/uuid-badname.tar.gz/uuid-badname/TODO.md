TODO
====

* Implement all RFC 4122 types
