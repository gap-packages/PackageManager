# Copyright and authors

The principal author and copyright holder of the uuid
package, elsewhere in this package referred to as "the uuid
team", is,

Markus Pfeiffer

# License

JupyterKernel is free software; you can redistribute it and/or modify
it under the terms of the BSD 3-clause license.

For details see the LICENSE file.
